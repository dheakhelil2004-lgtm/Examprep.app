import { useState, useEffect } from "react";

const MODULES = [
  {
    id: "pedagogy",
    title: "علوم التربية والبيداغوجيا",
    subtitle: "المناهج وطرق التدريس",
    icon: "📚",
    color: "#16a34a",
    bg: "linear-gradient(135deg, #052e16 0%, #14532d 100%)",
    border: "#22c55e",
    lessons: [
      { id: "mbc", title: "المقاربة بالكفاءات (MBC)" },
      { id: "lesson-planning", title: "التخطيط للدروس ومذكرة التحضير" },
      { id: "evaluation", title: "التقييم التربوي وأنواعه" },
      { id: "teaching-methods", title: "طرائق التدريس الحديثة" },
      { id: "edu-psychology", title: "علم النفس التربوي" },
    ],
  },
  {
    id: "legislation",
    title: "التشريع المدرسي",
    subtitle: "القوانين والتنظيم المدرسي",
    icon: "⚖️",
    color: "#d97706",
    bg: "linear-gradient(135deg, #1c1003 0%, #451a03 100%)",
    border: "#f59e0b",
    lessons: [
      { id: "law-0804", title: "قانون التربية الوطنية 08-04" },
      { id: "school-rules", title: "النظام الداخلي للمؤسسة التربوية" },
      { id: "teacher-rights", title: "حقوق وواجبات المعلم" },
      { id: "civil-service", title: "قانون الوظيف العمومي" },
    ],
  },
  {
    id: "culture",
    title: "الثقافة العامة",
    subtitle: "تاريخ الجزائر والمنظومة التربوية",
    icon: "🌍",
    color: "#2563eb",
    bg: "linear-gradient(135deg, #030712 0%, #1e3a8a 100%)",
    border: "#3b82f6",
    lessons: [
      { id: "algeria-history", title: "تاريخ الجزائر — الثورة والاستقلال" },
      { id: "edu-system", title: "المنظومة التربوية الجزائرية" },
      { id: "edu-reforms", title: "إصلاحات التعليم في الجزائر" },
      { id: "algeria-geo", title: "جغرافيا الجزائر وتنوعها" },
    ],
  },
  {
    id: "classroom",
    title: "إدارة الفصل والتلاميذ",
    subtitle: "التعامل والتحفيز والاندماج",
    icon: "👨‍🏫",
    color: "#9333ea",
    bg: "linear-gradient(135deg, #0f0720 0%, #4a044e 100%)",
    border: "#a855f7",
    lessons: [
      { id: "class-management", title: "ضبط الفصل وأساليب التحفيز" },
      { id: "individual-diff", title: "الفوارق الفردية بين التلاميذ" },
      { id: "special-needs", title: "التلاميذ ذوو الاحتياجات الخاصة" },
      { id: "parents", title: "العلاقة مع الأولياء والمجتمع المدرسي" },
      { id: "conflict", title: "حل النزاعات والتعامل مع المشكلات السلوكية" },
    ],
  },
];

// ── Calls our secure backend instead of Anthropic directly ──
async function callClaude(prompt) {
  const res = await fetch("/api/claude", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "API error");
  return data.text;
}

function parseLessonContent(raw) {
  const lines = raw.split("\n");
  const elements = [];
  let key = 0;
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    if (trimmed.startsWith("## ")) elements.push({ type: "h2", text: trimmed.slice(3), key: key++ });
    else if (trimmed.startsWith("# ")) elements.push({ type: "h1", text: trimmed.slice(2), key: key++ });
    else if (trimmed.startsWith("- ") || trimmed.startsWith("• ")) elements.push({ type: "bullet", text: trimmed.slice(2), key: key++ });
    else if (trimmed.startsWith("**") && trimmed.endsWith("**")) elements.push({ type: "bold", text: trimmed.slice(2, -2), key: key++ });
    else elements.push({ type: "p", text: trimmed, key: key++ });
  }
  return elements;
}

export default function App() {
  const [screen, setScreen] = useState("home");
  const [selectedModule, setSelectedModule] = useState(null);
  const [selectedLesson, setSelectedLesson] = useState(null);
  const [lessonParsed, setLessonParsed] = useState([]);
  const [quizData, setQuizData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState({});
  const [quizAnswers, setQuizAnswers] = useState({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("dz-exam-progress");
      if (saved) setProgress(JSON.parse(saved));
    } catch {}
  }, []);

  function saveProgress(lessonId, passed) {
    const updated = { ...progress, [lessonId]: passed ? "passed" : "attempted" };
    setProgress(updated);
    try { localStorage.setItem("dz-exam-progress", JSON.stringify(updated)); } catch {}
  }

  function getModuleProgress(mod) {
    const total = mod.lessons.length;
    const done = mod.lessons.filter((l) => progress[l.id] === "passed").length;
    return Math.round((done / total) * 100);
  }

  async function openLesson(mod, lesson) {
    setSelectedModule(mod);
    setSelectedLesson(lesson);
    setLessonParsed([]);
    setQuizData(null);
    setScreen("lesson");
    setLoading(true);
    try {
      const content = await callClaude(
        `أنت خبير في التعليم الجزائري. اكتب ملخصاً تعليمياً شاملاً باللغة العربية الفصحى حول الموضوع التالي:
"${lesson.title}"

الهدف: التحضير لمسابقة توظيف أساتذة الطور الابتدائي في الجزائر.

التنسيق المطلوب:
## [عنوان المحور الأول]
[شرح موجز وواضح]

المتطلبات:
- استخدم العربية الفصحى السهلة
- ركّز على ما يُسأل عنه في المسابقة
- اذكر التعريفات والمفاهيم الأساسية
- أضف أمثلة تطبيقية مناسبة
- الطول: 350 إلى 500 كلمة`
      );
      setLessonParsed(parseLessonContent(content));
    } catch {
      setLessonParsed([{ type: "p", text: "حدث خطأ في تحميل المحتوى. يرجى المحاولة مجدداً.", key: 0 }]);
    }
    setLoading(false);
  }

  async function startQuiz() {
    setScreen("quiz");
    setQuizData(null);
    setQuizAnswers({});
    setQuizSubmitted(false);
    setLoading(true);
    try {
      const raw = await callClaude(
        `أنت خبير في مسابقات توظيف الأساتذة الجزائرية. أنشئ 5 أسئلة اختيار من متعدد (QCM) دقيقة باللغة العربية حول:
"${selectedLesson.title}"

أجب فقط بـ JSON نقي بدون أي تعليق أو Markdown:
{"questions":[{"question":"نص السؤال","options":["الخيار أ","الخيار ب","الخيار ج","الخيار د"],"correct":0,"explanation":"شرح الإجابة الصحيحة"}]}`
      );
      const clean = raw.replace(/```json|```/g, "").trim();
      setQuizData(JSON.parse(clean));
    } catch {
      setQuizData({ error: true });
    }
    setLoading(false);
  }

  function submitQuiz() {
    if (!quizData?.questions) return;
    let correct = 0;
    quizData.questions.forEach((q, i) => { if (quizAnswers[i] === q.correct) correct++; });
    const pct = Math.round((correct / quizData.questions.length) * 100);
    setScore(pct);
    setQuizSubmitted(true);
    saveProgress(selectedLesson.id, pct >= 60);
  }

  const S = {
    app: { direction: "rtl", fontFamily: "'Cairo', 'Segoe UI', sans-serif", background: "#050d0a", minHeight: "100vh", color: "#e8f5e9" },
    header: { background: "linear-gradient(180deg, #071a10 0%, #050d0a 100%)", borderBottom: "1px solid #1a3d24", padding: "16px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 100 },
    backBtn: { background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)", color: "#a7f3c0", borderRadius: "10px", padding: "8px 16px", cursor: "pointer", fontSize: "14px", display: "flex", alignItems: "center", gap: "6px", fontFamily: "'Cairo', sans-serif" },
    content: { padding: "20px", maxWidth: "700px", margin: "0 auto" },
  };

  const totalLessons = MODULES.reduce((a, m) => a + m.lessons.length, 0);
  const totalPassed = Object.values(progress).filter((v) => v === "passed").length;
  const overallPct = Math.round((totalPassed / totalLessons) * 100);

  const globalStyles = `
    @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap');
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { background: #050d0a; }
    ::-webkit-scrollbar { width: 6px; } ::-webkit-scrollbar-track { background: #050d0a; } ::-webkit-scrollbar-thumb { background: #1a4a2a; border-radius: 3px; }
    @keyframes fadeUp { from { opacity:0; transform: translateY(20px); } to { opacity:1; transform: translateY(0); } }
    @keyframes spin { to { transform: rotate(360deg); } }
    .mod-card { transition: transform 0.2s, box-shadow 0.2s; cursor: pointer; }
    .mod-card:hover { transform: translateY(-4px); box-shadow: 0 12px 40px rgba(0,0,0,0.5) !important; }
    .lesson-row { transition: background 0.15s, transform 0.15s; cursor: pointer; }
    .lesson-row:hover { background: rgba(255,255,255,0.08) !important; transform: translateX(-4px); }
    .quiz-option { transition: all 0.15s; cursor: pointer; user-select: none; }
    .quiz-option:hover { transform: translateX(-3px); }
    .btn-p { transition: all 0.2s; cursor: pointer; }
    .btn-p:hover { opacity: 0.85; transform: translateY(-1px); }
  `;

  if (screen === "home") return (
    <div style={S.app}>
      <style>{globalStyles}</style>
      <div style={{ ...S.header, justifyContent: "center", flexDirection: "column", gap: "4px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <span style={{ fontSize: "24px" }}>🇩🇿</span>
          <span style={{ fontSize: "18px", fontWeight: 900, color: "#4ade80" }}>مسابقة الأساتذة — الطور الابتدائي</span>
        </div>
        <span style={{ fontSize: "12px", color: "#6b7280" }}>منصة التحضير الذكية</span>
      </div>
      <div style={S.content}>
        <div style={{ background: "linear-gradient(135deg, #064e3b, #0a3d2e)", border: "1px solid #065f46", borderRadius: "16px", padding: "20px", marginBottom: "24px", animation: "fadeUp 0.4s ease" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "12px" }}>
            <div>
              <div style={{ fontSize: "13px", color: "#6ee7b7", marginBottom: "4px" }}>تقدمك العام</div>
              <div style={{ fontSize: "28px", fontWeight: 900, color: "#fff" }}>{overallPct}%</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: "22px", fontWeight: 700, color: "#4ade80" }}>{totalPassed}</div>
              <div style={{ fontSize: "11px", color: "#6b7280" }}>درس مكتمل من {totalLessons}</div>
            </div>
          </div>
          <div style={{ background: "rgba(0,0,0,0.3)", borderRadius: "999px", height: "8px", overflow: "hidden" }}>
            <div style={{ width: `${overallPct}%`, height: "100%", background: "linear-gradient(90deg, #16a34a, #4ade80)", borderRadius: "999px", transition: "width 0.6s ease" }} />
          </div>
        </div>
        <div style={{ fontSize: "13px", color: "#6b7280", marginBottom: "14px", fontWeight: 600 }}>اختر المحور الذي تريد مراجعته</div>
        {MODULES.map((mod, idx) => {
          const pct = getModuleProgress(mod);
          return (
            <div key={mod.id} className="mod-card" onClick={() => { setSelectedModule(mod); setScreen("module"); }} style={{ background: mod.bg, border: `1px solid ${mod.border}22`, borderRadius: "16px", padding: "20px", marginBottom: "14px", animation: `fadeUp 0.4s ease ${idx * 0.08}s both`, boxShadow: "0 4px 20px rgba(0,0,0,0.3)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "6px" }}>
                    <span style={{ fontSize: "24px" }}>{mod.icon}</span>
                    <div>
                      <div style={{ fontSize: "16px", fontWeight: 800, color: "#fff" }}>{mod.title}</div>
                      <div style={{ fontSize: "12px", color: "rgba(255,255,255,0.5)" }}>{mod.subtitle}</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginTop: "10px" }}>
                    <div style={{ flex: 1, background: "rgba(0,0,0,0.3)", borderRadius: "999px", height: "5px", overflow: "hidden" }}>
                      <div style={{ width: `${pct}%`, height: "100%", background: mod.color, borderRadius: "999px", transition: "width 0.6s" }} />
                    </div>
                    <span style={{ fontSize: "12px", color: "rgba(255,255,255,0.6)", minWidth: "30px" }}>{pct}%</span>
                  </div>
                </div>
                <div style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: "10px", padding: "6px 10px", fontSize: "12px", color: "rgba(255,255,255,0.6)", marginRight: "8px", whiteSpace: "nowrap" }}>{mod.lessons.length} دروس</div>
              </div>
            </div>
          );
        })}
        <div style={{ height: "32px" }} />
      </div>
    </div>
  );

  if (screen === "module") {
    const mod = selectedModule;
    return (
      <div style={S.app}>
        <style>{globalStyles}</style>
        <div style={S.header}>
          <button className="btn-p" style={S.backBtn} onClick={() => setScreen("home")}>← الرئيسية</button>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}><span>{mod.icon}</span><span style={{ fontWeight: 800, fontSize: "15px" }}>{mod.title}</span></div>
          <div style={{ width: "80px" }} />
        </div>
        <div style={S.content}>
          <div style={{ background: mod.bg, border: `1px solid ${mod.border}33`, borderRadius: "14px", padding: "16px 20px", marginBottom: "20px", animation: "fadeUp 0.3s ease" }}>
            <div style={{ fontSize: "13px", color: "rgba(255,255,255,0.55)" }}>{mod.subtitle}</div>
            <div style={{ fontSize: "12px", color: mod.color, marginTop: "4px", fontWeight: 600 }}>{mod.lessons.filter((l) => progress[l.id] === "passed").length} / {mod.lessons.length} دروس مكتملة</div>
          </div>
          <div style={{ fontSize: "13px", color: "#6b7280", marginBottom: "12px", fontWeight: 600 }}>اختر درساً</div>
          {mod.lessons.map((lesson, idx) => {
            const status = progress[lesson.id];
            return (
              <div key={lesson.id} className="lesson-row" onClick={() => openLesson(mod, lesson)} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px", padding: "16px 18px", marginBottom: "10px", display: "flex", alignItems: "center", justifyContent: "space-between", animation: `fadeUp 0.35s ease ${idx * 0.06}s both` }}>
                <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                  <div style={{ width: "36px", height: "36px", borderRadius: "50%", background: status === "passed" ? "#16a34a" : status === "attempted" ? "#92400e" : "rgba(255,255,255,0.08)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "16px", flexShrink: 0, border: `2px solid ${status === "passed" ? "#4ade80" : status === "attempted" ? "#f59e0b" : "rgba(255,255,255,0.15)"}` }}>
                    {status === "passed" ? "✓" : status === "attempted" ? "○" : idx + 1}
                  </div>
                  <div>
                    <div style={{ fontSize: "15px", fontWeight: 700, color: "#e8f5e9" }}>{lesson.title}</div>
                    <div style={{ fontSize: "11px", color: "#4b5563", marginTop: "2px" }}>{status === "passed" ? "✅ مكتمل" : status === "attempted" ? "⏳ يحتاج مراجعة" : "لم يُدرس بعد"}</div>
                  </div>
                </div>
                <span style={{ color: "#4b5563", fontSize: "18px" }}>›</span>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  if (screen === "lesson") {
    const mod = selectedModule;
    return (
      <div style={S.app}>
        <style>{globalStyles}</style>
        <div style={S.header}>
          <button className="btn-p" style={S.backBtn} onClick={() => setScreen("module")}>← {mod.title}</button>
          <div style={{ fontSize: "13px", color: "#6b7280", flex: 1, textAlign: "center" }}>📖 الملخص</div>
          <div style={{ width: "100px" }} />
        </div>
        <div style={S.content}>
          <div style={{ background: mod.bg, border: `1px solid ${mod.border}33`, borderRadius: "14px", padding: "16px 20px", marginBottom: "20px" }}>
            <div style={{ fontSize: "17px", fontWeight: 900, color: "#fff" }}>{selectedLesson?.title}</div>
            <div style={{ fontSize: "12px", color: "rgba(255,255,255,0.4)", marginTop: "4px" }}>{mod.icon} {mod.title}</div>
          </div>
          {loading ? (
            <div style={{ textAlign: "center", padding: "60px 20px" }}>
              <div style={{ width: "40px", height: "40px", border: "3px solid rgba(255,255,255,0.1)", borderTop: `3px solid ${mod.color}`, borderRadius: "50%", animation: "spin 0.8s linear infinite", margin: "0 auto 16px" }} />
              <div style={{ color: "#6b7280", fontSize: "14px" }}>يجهّز الذكاء الاصطناعي الملخص...</div>
            </div>
          ) : (
            <div style={{ animation: "fadeUp 0.4s ease" }}>
              {lessonParsed.map((el) => {
                if (el.type === "h1" || el.type === "h2") return <div key={el.key} style={{ fontSize: el.type === "h1" ? "17px" : "15px", fontWeight: 800, color: mod.color, margin: "20px 0 8px", paddingBottom: "6px", borderBottom: `1px solid ${mod.border}33`, display: "flex", alignItems: "center", gap: "8px" }}><span style={{ fontSize: "10px", opacity: 0.7 }}>◆</span> {el.text}</div>;
                if (el.type === "bullet") return <div key={el.key} style={{ display: "flex", gap: "10px", marginBottom: "7px", paddingRight: "8px" }}><span style={{ color: mod.color, flexShrink: 0, marginTop: "4px" }}>•</span><span style={{ fontSize: "14px", lineHeight: "1.7", color: "#d1fae5" }}>{el.text}</span></div>;
                if (el.type === "bold") return <div key={el.key} style={{ fontWeight: 700, color: "#fff", marginBottom: "6px", fontSize: "14px" }}>{el.text}</div>;
                return <p key={el.key} style={{ fontSize: "14px", lineHeight: "1.8", color: "#a7f3c0", marginBottom: "8px" }}>{el.text}</p>;
              })}
              <div style={{ height: "20px" }} />
              <button className="btn-p" onClick={startQuiz} style={{ width: "100%", padding: "16px", background: `linear-gradient(135deg, ${mod.color}, ${mod.border})`, border: "none", borderRadius: "14px", fontSize: "16px", fontWeight: 800, color: "#fff", cursor: "pointer", fontFamily: "'Cairo', sans-serif", boxShadow: `0 4px 20px ${mod.color}44` }}>✅ ابدأ الاختبار</button>
              <div style={{ height: "32px" }} />
            </div>
          )}
        </div>
      </div>
    );
  }

  if (screen === "quiz") {
    const mod = selectedModule;
    const allAnswered = quizData?.questions && quizData.questions.every((_, i) => quizAnswers[i] !== undefined);
    return (
      <div style={S.app}>
        <style>{globalStyles}</style>
        <div style={S.header}>
          <button className="btn-p" style={S.backBtn} onClick={() => setScreen("lesson")}>← الملخص</button>
          <div style={{ fontSize: "13px", fontWeight: 700 }}>🧠 اختبار تقييمي</div>
          <div style={{ width: "90px" }} />
        </div>
        <div style={S.content}>
          {loading ? (
            <div style={{ textAlign: "center", padding: "60px 20px" }}>
              <div style={{ width: "40px", height: "40px", border: "3px solid rgba(255,255,255,0.1)", borderTop: `3px solid ${mod.color}`, borderRadius: "50%", animation: "spin 0.8s linear infinite", margin: "0 auto 16px" }} />
              <div style={{ color: "#6b7280", fontSize: "14px" }}>يُعدّ الأسئلة...</div>
            </div>
          ) : quizData?.error ? (
            <div style={{ textAlign: "center", padding: "40px 20px" }}>
              <div style={{ fontSize: "40px", marginBottom: "12px" }}>⚠️</div>
              <div style={{ color: "#f87171", marginBottom: "20px" }}>حدث خطأ. يرجى المحاولة مجدداً.</div>
              <button className="btn-p" onClick={startQuiz} style={{ background: mod.color, border: "none", borderRadius: "10px", padding: "12px 24px", color: "#fff", fontFamily: "'Cairo',sans-serif", fontSize: "15px", fontWeight: 700, cursor: "pointer" }}>إعادة المحاولة</button>
            </div>
          ) : quizData?.questions ? (
            quizSubmitted ? (
              <div style={{ animation: "fadeUp 0.4s ease" }}>
                <div style={{ background: score >= 60 ? "linear-gradient(135deg, #064e3b, #065f46)" : "linear-gradient(135deg, #450a0a, #7f1d1d)", border: `1px solid ${score >= 60 ? "#16a34a" : "#b91c1c"}`, borderRadius: "16px", padding: "24px", textAlign: "center", marginBottom: "24px" }}>
                  <div style={{ fontSize: "48px", marginBottom: "8px" }}>{score >= 80 ? "🏆" : score >= 60 ? "✅" : "📚"}</div>
                  <div style={{ fontSize: "42px", fontWeight: 900, color: score >= 60 ? "#4ade80" : "#f87171" }}>{score}%</div>
                  <div style={{ fontSize: "15px", color: "rgba(255,255,255,0.7)", marginTop: "6px" }}>{score >= 80 ? "ممتاز! أداء رائع" : score >= 60 ? "جيد! اجتزت الاختبار" : "تحتاج مراجعة أكثر"}</div>
                </div>
                {quizData.questions.map((q, i) => {
                  const correct = quizAnswers[i] === q.correct;
                  return (
                    <div key={i} style={{ background: correct ? "rgba(22,163,74,0.12)" : "rgba(239,68,68,0.12)", border: `1px solid ${correct ? "#16a34a" : "#ef4444"}33`, borderRadius: "12px", padding: "16px", marginBottom: "12px" }}>
                      <div style={{ fontSize: "13px", fontWeight: 700, color: "#e8f5e9", marginBottom: "10px" }}>{correct ? "✅" : "❌"} {q.question}</div>
                      <div style={{ fontSize: "12px", color: "#6ee7b7", marginBottom: "6px" }}>الإجابة الصحيحة: {q.options[q.correct]}</div>
                      {q.explanation && <div style={{ fontSize: "12px", color: "#6b7280", fontStyle: "italic" }}>💡 {q.explanation}</div>}
                    </div>
                  );
                })}
                <div style={{ display: "flex", gap: "10px", marginTop: "16px" }}>
                  <button className="btn-p" onClick={() => { setQuizAnswers({}); setQuizSubmitted(false); }} style={{ flex: 1, padding: "14px", background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: "12px", color: "#e8f5e9", fontFamily: "'Cairo',sans-serif", fontSize: "14px", fontWeight: 700, cursor: "pointer" }}>🔁 إعادة الاختبار</button>
                  <button className="btn-p" onClick={() => setScreen("module")} style={{ flex: 1, padding: "14px", background: mod.color, border: "none", borderRadius: "12px", color: "#fff", fontFamily: "'Cairo',sans-serif", fontSize: "14px", fontWeight: 700, cursor: "pointer" }}>← الدروس</button>
                </div>
                <div style={{ height: "32px" }} />
              </div>
            ) : (
              <div style={{ animation: "fadeUp 0.3s ease" }}>
                <div style={{ fontSize: "12px", color: "#6b7280", marginBottom: "18px", textAlign: "center" }}>أجب على جميع الأسئلة ثم اضغط إرسال</div>
                {quizData.questions.map((q, qi) => (
                  <div key={qi} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "14px", padding: "18px", marginBottom: "14px" }}>
                    <div style={{ fontSize: "14px", fontWeight: 700, color: "#e8f5e9", marginBottom: "14px", lineHeight: "1.6" }}><span style={{ color: mod.color, marginLeft: "6px", fontWeight: 900 }}>{qi + 1}.</span>{q.question}</div>
                    {q.options.map((opt, oi) => {
                      const selected = quizAnswers[qi] === oi;
                      return (
                        <div key={oi} className="quiz-option" onClick={() => setQuizAnswers({ ...quizAnswers, [qi]: oi })} style={{ background: selected ? `${mod.color}22` : "rgba(255,255,255,0.04)", border: `1.5px solid ${selected ? mod.color : "rgba(255,255,255,0.1)"}`, borderRadius: "10px", padding: "11px 14px", marginBottom: "8px", fontSize: "13px", color: selected ? "#fff" : "#9ca3af", display: "flex", alignItems: "center", gap: "10px" }}>
                          <div style={{ width: "22px", height: "22px", borderRadius: "50%", border: `2px solid ${selected ? mod.color : "rgba(255,255,255,0.2)"}`, background: selected ? mod.color : "transparent", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: "11px", color: "#fff", fontWeight: 700 }}>{selected ? "✓" : ["أ", "ب", "ج", "د"][oi]}</div>
                          {opt}
                        </div>
                      );
                    })}
                  </div>
                ))}
                <button className="btn-p" onClick={submitQuiz} disabled={!allAnswered} style={{ width: "100%", padding: "16px", background: allAnswered ? `linear-gradient(135deg, ${mod.color}, ${mod.border})` : "rgba(255,255,255,0.08)", border: allAnswered ? "none" : "1px solid rgba(255,255,255,0.1)", borderRadius: "14px", fontSize: "16px", fontWeight: 800, color: allAnswered ? "#fff" : "#4b5563", cursor: allAnswered ? "pointer" : "not-allowed", fontFamily: "'Cairo',sans-serif", boxShadow: allAnswered ? `0 4px 20px ${mod.color}44` : "none" }}>
                  {allAnswered ? "✅ إرسال الإجابات" : `أجب على ${quizData.questions.length - Object.keys(quizAnswers).length} سؤال متبقي`}
                </button>
                <div style={{ height: "32px" }} />
              </div>
            )
          ) : null}
        </div>
      </div>
    );
  }

  return null;
}
